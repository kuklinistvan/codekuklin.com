#include "libsocket/headers/libunixsocket.h"
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "time_str_provider.h"

void answer_calls(int socketd);
sds construct_message(sds target);

int main(int argc, char *argv[]) {

  if (argc != 2) {
    printf("Usage: %s <socket_path>\n", argv[0]);
    _exit(1);
  }

  int socketd = create_unix_server_socket(argv[1], LIBSOCKET_STREAM, 0);

  if (socketd == -1) {
    printf("Failed to bind to socket at %s.\n", argv[1]);
    _exit(1);
  }

  answer_calls(socketd);
}

void answer_calls(int socketd) {
  sds sendbuf = sdsempty();

  for (;;) {
    printf("Waiting for new connection...\n");
    int connection = accept_unix_stream_socket(socketd, 0);

    if (connection == -1) {
      printf("Failed to accept connection.\n");
      continue;
    }

    sendbuf = construct_message(sendbuf);

    printf("Answering call with message: %s (length: %d)\n", sendbuf,
           sdslen(sendbuf));
    write(connection, sendbuf, sdslen(sendbuf) * sizeof(char));

    printf("Hang up\n");
    destroy_unix_socket(connection);
  }

  sdsfree(sendbuf);
}

sds construct_message(sds target) {
  target = sdscpy(target, "Local time is: ");
  target = cat_current_time_string_into(target);
  target = sdscat(target, "\n");
  return target;
}
