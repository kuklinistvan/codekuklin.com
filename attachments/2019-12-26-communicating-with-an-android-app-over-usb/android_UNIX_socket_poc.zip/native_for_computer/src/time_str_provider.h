#pragma once
#include "sds/sds.h"

sds cat_current_time_string_into(sds target);
