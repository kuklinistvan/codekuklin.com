package com.codekuklin.unix_socket_time_applet;

import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LocalTimeSocketServer {

    private LocalServerSocket serverSocket;

    public void startServer() throws IOException {
        serverSocket = new LocalServerSocket("com.codekuklin.unix_socket_time_applet.time_applet");
        new Thread(() -> {
            for(;;) {
                try {
                    LocalSocket connection = serverSocket.accept();
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));

                    String currentTime = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                    Log.i(getClass().getName(), "Writing to socket: " + currentTime);

                    String out = "Current time: " + currentTime + "\n";

                    writer.write(out);
                    writer.flush();

                    connection.shutdownOutput();
                    connection.close();
                } catch (IOException e) {
                    Log.e(getClass().getName(), "", e);
                }
            }
        }).start();
    }


}
