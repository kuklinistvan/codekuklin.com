#include "time_str_provider.h"
#include "sds/sds.h"
#include <time.h>

sds cat_current_time_string_into(sds target) {   
    char buf[150];
    time_t now = time(NULL);
    
    strftime(buf, 150, "%Y-%m-%d %T", localtime(&now));
    
    target = sdscat(target, buf);
    return target;
}
