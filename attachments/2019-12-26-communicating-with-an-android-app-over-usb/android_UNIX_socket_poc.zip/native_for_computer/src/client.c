#include <stdio.h>
#include <unistd.h>

#include "sds/sds.h"
#include "libunixsocket.h"

void read_one_message(int socketfd);

int main(int argc, char *argv[]) {
    
    if(argc != 2) {
        printf("Usage: %s <socket_path>\n", argv[0]);
        _exit(1);
    }

    // int socketd = create_unix_server_socket(argv[1], LIBSOCKET_STREAM, 0);
    
    int socketd = create_unix_stream_socket(argv[1], 0);
    
    if ( socketd == -1 ) {
        printf("Failed to connect to socket.");
        _exit(2);
    }
    
    read_one_message(socketd);
    
    shutdown_unix_stream_socket(socketd, 0);
}

void read_one_message(int socketfd) {
    size_t buf_len = 150;
    char buf[buf_len];    
    read(socketfd, buf, buf_len);
    printf("Got message: %s", buf);
}
