package com.codekuklin.unix_socket_time_applet;

import androidx.appcompat.app.AppCompatActivity;

import android.net.LocalServerSocket;
import android.os.Bundle;
import android.util.Log;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            new LocalTimeSocketServer().startServer();
        } catch (IOException e) {
            Log.e(getClass().getName(), "", e);
        }
    }
}
